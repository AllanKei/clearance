<?php

session_start();

include"includes/header.php";
include"includes/navbar.php";
include"includes/sidebar.php";

?>


  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>
              Dean of school
            </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"> Dean of school</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card card-primary card-outline card-outline-tabs">
                        <div class="card-header p-0 border-bottom-0">
                            <ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="custom-tabs-four-home-tab" data-toggle="pill" href="#pending" role="tab" aria-controls="pending" aria-selected="true">Students Pending clearance</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-four-profile-tab" data-toggle="pill" href="#cleared" role="tab" aria-controls="cleared" aria-selected="false">Cleared students</a>
                                </li>
                            </ul>
                        </div>
                        <div class="card-body">
                            <div class="tab-content" id="custom-tabs-four-tabContent">
                                <div class="tab-pane fade show active" id="pending" role="tabpanel" aria-labelledby="pending">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th>Student Names</th>
                                            <th>Registration Number</th>
                                            <th>Charges</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Trident</td>
                                            <td>1</td>
                                            <td>2</td>
                                            <td>X</td>
                                            <td>y</td>
                                        </tr>
                                        
                                        
                                    </table>
                                </div>
                                <div class="tab-pane fade" id="cleared" role="tabpanel" aria-labelledby="cleared">
                                <table id="example2" class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th>Student Name</th>
                                            <th>Registration Number</th>
                                            <th>Remarks</th>
                                            <th>Charges</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Trident</td>
                                            <td>Win 95+</td>
                                            <td> 4</td>
                                            <td>1</td>
                                            <td>2</td>
                                            <td>X</td>
                                        </tr>
                                    </table>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    </div>
</div>
  <!-- /.content-wrapper -->
 
<?php
include"includes/footer.php";
include"includes/scripts.php";
?>
