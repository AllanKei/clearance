<?php
session_start();
include"includes/header.php";

?>

<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href=""><b>Clearance</b> system</a>
  </div>
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
        <?php

        if(isset($_SESSION['error'])){
            echo "
                <div class='alert alert-danger text-center'>
                <a href='#' class='close' style='text-decoration: none;' data-dismiss='alert' aria-label='close'>&times;</a>
                    <p>".$_SESSION['error']."</p> 
                </div>
                ";
            unset($_SESSION['error']);
        }

        if(isset($_SESSION['success'])){
            echo "
                <div class='alert alert-success text-center'>
                <a href='#' class='close' style='text-decoration: none;' data-dismiss='alert' aria-label='close'>&times;</a>
                    <p>".$_SESSION['success']."</p> 
                </div>
                ";
            unset($_SESSION['success']);
        }
        ?>
      <p class="login-box-msg">Sign in to start your session</p>

        <form role="form" id="quickForm" action="action.php" method="post">
            <div class="card-body">
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                </div>
            </div>
            <div class="">
                <button type="submit" name="login" class="btn btn-primary btn-block">Sign In</button>
            </div>
        </form>
        <br>
      <!--<p class="mb-1">
        <a href="forgot-password.html">Forgot your password?</a>
      </p>-->
    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- jquery-validation -->
<script src="plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="plugins/jquery-validation/additional-methods.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
      $.validator.setDefaults({
        
      });
      $('#quickForm').validate({
        rules: {
          email: {
            required: true,
            email: true,
          },
          password: {
            required: true,
            minlength: 5
          },
          terms: {
            required: true
          },
        },
        messages: {
          email: {
            required: "Please enter a email address",
            email: "Please enter a vaild email address"
          },
          password: {
            required: "Please provide a password",
            minlength: "Your password must be at least 5 characters long"
          },
          terms: "Please accept our terms"
        },
        errorElement: 'span',
        errorPlacement: function (error, element) {
          error.addClass('invalid-feedback');
          element.closest('.form-group').append(error);
        },
        highlight: function (element, errorClass, validClass) {
          $(element).addClass('is-invalid');
        },
        unhighlight: function (element, errorClass, validClass) {
          $(element).removeClass('is-invalid');
        }
      });
    });
    </script>

</body>
</html>